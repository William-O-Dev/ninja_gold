from django.urls import path, include

urlpatterns = [
    path('', include('ninja_gold_app.urls')),
]
